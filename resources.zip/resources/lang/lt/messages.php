<?php
return [
    'welcome' => 'Sveiki atvykę',
    'conference' => 'Konferencija',
    'register' => 'Registruotis',
];
