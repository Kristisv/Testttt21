<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administratoriaus Puslapis</title>
</head>
<body>
<h1>Sistemos Administratorius</h1>
<p>Čia galite valdyti konferencijas ir naudotojų informaciją.</p>
</body>
</html>
